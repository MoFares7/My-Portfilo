export const skillsData = [
    'Figma',
    'Javascript',
    'CSS',
    "React",
    "Next JS",
    "Docker",
    "Adobe XD",
    "Java",
    "Laravel",
    "Flutter",
    "Dart",
    "Typescript",
    "Git",
    "Tailwind",
    "ViteJS",
    "MySQL",
    "PostgreSQL",
    "Firebase",
    "Adobe Audition",
    "MaterialUI",
]

// Choose your skills from below. Make sure it's in the same format and spelled correctly.
// Couldn't find the required skills? Raise an issue on github at https://github.com/hhhrrrttt222111/developer-portfolio/issues/new


// AVAILABLE SKILLS

/* 
   
    
    React Js
    Next JS

    Docker


    Adobe XD


    Java
JS 
    PHP
    Flutter
    Dart
    Typescript

    Git
    Figma


    Tailwind
    ViteJS

    MySQL
    PostgreSQL

    Firebase

    Adobe Audition

    MaterialUI
    Strapi
  
*/

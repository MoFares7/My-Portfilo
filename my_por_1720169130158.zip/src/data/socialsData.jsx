export const socialsData = {
    github: 'https://github.com/MoFares7',
    facebook: 'https://www.facebook.com/',
    linkedIn: 'https://www.linkedin.com/in',
    instagram: 'https://www.instagram.com/',
    codepen: 'https://codepen.io/',
    twitter: 'https://twitter.com/',
    reddit: 'https://www.reddit.com/user/',
    blogger: 'https://www.blogger.com/',
    medium: 'https://medium.com/@faresdabbas1',
    stackOverflow: 'https://stackoverflow.com/users/20133739/mo-fares',
    gitlab: 'https://gitlab.com/MoFares',
    youtube: 'https://youtube.com/'
}
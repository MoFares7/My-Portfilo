export const aboutData = {
    title: "Who I am",
    description1: "I have experience two years in developing mobile apps using (Flutter), and one year in developing web sites using (React Js)",
    description2: "am committed to achieving quality and innovation in every project I work on.I use contemporary languages and techniques and follow standards to ensure that a premium finished product is delivered and suited to customers' needs.",
    description3: "I work effectively in multidisciplinary teams and communicate well with customers and colleagues.I am able to manage projects and organize time effectively to meet deadlines and achieve the required results.",
    image: 1
}
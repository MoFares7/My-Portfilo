export const contactsData = {
    email: 'faresdabbas1@gmail.com',
    phone: '+963-982509861',
    address: 'Damascus, Syria ',

    sheetAPI: ''
}
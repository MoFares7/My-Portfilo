export const experienceData = [
    {
        id: 1,
        company: 'Deep Blue Technologies ',
        jobtitle: 'Mobile App Developer',
        startYear: '3/6/2022',
        endYear: '5/1/2023'
    },
    {
        id: 2,
        company: 'FreeLanceer',
        jobtitle: 'FrontEnd Developer',
        startYear: '1/2/2023',
        endYear: 'Present'
    },
]
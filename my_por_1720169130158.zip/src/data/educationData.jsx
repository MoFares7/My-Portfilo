export const educationData = [
    {
        id: 1,
        institution: 'Damascus Univarsity',
        course: 'Information Technology Engineering',
        startYear: '2019',
        endYear: '2022'
    },
    {
        id: 2,
        institution: 'Damascus Univarsity',
        course: 'Bachelor of Software Engineering',
        startYear: '2022',
        endYear: '2024'
    },

]
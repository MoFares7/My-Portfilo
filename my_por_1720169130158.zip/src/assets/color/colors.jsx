const colors = {
        main: {
                default: "'#3a86ff'",
        },
}
export default colors;